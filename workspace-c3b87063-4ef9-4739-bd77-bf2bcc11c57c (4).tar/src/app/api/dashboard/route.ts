import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { 
  orders, orderItems, products, productViews, cartEvents, customers,
  categories, variants
} from '@/db/schema'
import { eq, sql, and, gte, lte, desc } from 'drizzle-orm'

// GET /api/dashboard - Get comprehensive dashboard analytics
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const timeFrame = searchParams.get('timeFrame') || '30d'

  try {
    // Calculate date range
    const now = new Date()
    let days = 30
    if (timeFrame === 'today') days = 1
    else if (timeFrame === '7d') days = 7
    else if (timeFrame === '15d') days = 15
    else if (timeFrame === '30d') days = 30
    else if (timeFrame === '45d') days = 45
    else if (timeFrame === '3m') days = 90
    else if (timeFrame === '6m') days = 180
    else if (timeFrame === '1y') days = 365

    const startDate = new Date(now)
    startDate.setDate(startDate.getDate() - (days - 1))
    startDate.setHours(0, 0, 0, 0)

    // =============================================
    // 1. FETCH ALL ORDERS
    // =============================================
    const allOrders = await db.select().from(orders)
    
    // Filter by time frame
    const filteredOrders = allOrders.filter(o => {
      if (!o.createdAt) return false
      return new Date(o.createdAt) >= startDate
    })

    // Approved orders in time frame
    const approvedOrders = filteredOrders.filter(o => o.status === 'approved')
    
    // =============================================
    // 2. CALCULATE REVENUE & SALES
    // =============================================
    const totalRevenue = approvedOrders.reduce((sum, o) => {
      return sum + Math.round(parseFloat(String(o.total)) || 0)
    }, 0)

    const totalOrdersCount = approvedOrders.length
    const pendingOrdersCount = filteredOrders.filter(o => o.status === 'pending').length
    const canceledOrdersCount = filteredOrders.filter(o => o.status === 'canceled').length

    // =============================================
    // 3. CUSTOMER METRICS
    // =============================================
    // Get unique customers from orders (by phone)
    const customerMap: Record<string, { count: number; totalSpent: number; name: string }> = {}
    
    allOrders.forEach(order => {
      const phone = order.phone?.replace(/\D/g, '')
      if (phone) {
        if (!customerMap[phone]) {
          customerMap[phone] = { count: 0, totalSpent: 0, name: order.customerName || 'Unknown' }
        }
        customerMap[phone].count += 1
        customerMap[phone].totalSpent += Math.round(parseFloat(String(order.total)) || 0)
        customerMap[phone].name = order.customerName || customerMap[phone].name
      }
    })

    const totalCustomers = Object.keys(customerMap).length
    const repeatCustomersCount = Object.values(customerMap).filter(c => c.count > 1).length
    const newCustomers = totalCustomers - repeatCustomersCount

    // Top customers
    const topCustomers = Object.entries(customerMap)
      .map(([phone, data]) => ({
        name: data.name,
        phone: phone,
        totalSpent: data.totalSpent,
        orderCount: data.count
      }))
      .sort((a, b) => b.totalSpent - a.totalSpent)
      .slice(0, 5)

    // =============================================
    // 4. PRODUCT VIEWS (REAL DATA)
    // =============================================
    const allProductViews = await db.select().from(productViews)
    
    // Filter by time frame
    const filteredViews = allProductViews.filter(v => {
      if (!v.date) return false
      const viewDate = new Date(v.date)
      return viewDate >= startDate
    })

    // Total views in time frame
    const totalViews = filteredViews.reduce((sum, v) => sum + (v.viewCount || 0), 0)
    
    // Unique products viewed
    const uniqueProductsViewed = new Set(filteredViews.map(v => v.productId)).size

    // =============================================
    // 5. PRODUCT SALES DATA
    // =============================================
    // Get all order items for approved orders
    const approvedOrderIds = approvedOrders.map(o => o.id)
    let productSales: Record<string, { name: string; sales: number; revenue: number; category: string }> = {}

    if (approvedOrderIds.length > 0) {
      // Fetch order items
      const items = await db.select().from(orderItems)
      const filteredItems = items.filter(item => approvedOrderIds.includes(item.orderId || ''))
      
      // Fetch products for category info
      const allProducts = await db.select().from(products)
      const productMap = new Map(allProducts.map(p => [p.id, p]))

      for (const item of filteredItems) {
        const name = item.name
        if (!productSales[name]) {
          const product = item.productId ? productMap.get(item.productId) : null
          productSales[name] = {
            name,
            sales: 0,
            revenue: 0,
            category: product?.category || 'Other'
          }
        }
        productSales[name].sales += item.qty
        productSales[name].revenue += Math.round(parseFloat(String(item.basePrice)) || 0) * item.qty
      }
    }

    // Get product views for each product
    const productViewCounts: Record<number, number> = {}
    for (const v of filteredViews) {
      productViewCounts[v.productId] = (productViewCounts[v.productId] || 0) + (v.viewCount || 0)
    }

    // Combine sales and views for top products
    const productStatsArray = Object.values(productSales).map(p => {
      // Find product by name to get views
      const product = Object.entries(productViewCounts).find(([id]) => {
        // This is a simplified match - in production you'd join properly
        return true
      })
      return {
        ...p,
        views: productViewCounts[parseInt(Object.keys(productViewCounts)[0])] || 0
      }
    })

    // Top selling products
    const topSellingProducts = Object.values(productSales)
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 5)

    // Most viewed products
    const mostViewedProducts = await db
      .select({
        productId: productViews.productId,
        totalViews: sql<number>`sum(${productViews.viewCount})`.as('totalViews'),
      })
      .from(productViews)
      .where(gte(productViews.date, startDate.toISOString().split('T')[0]))
      .groupBy(productViews.productId)
      .orderBy(desc(sql`sum(${productViews.viewCount})`))
      .limit(5)

    // Get product details for viewed products
    const viewedProductsWithDetails = await Promise.all(
      mostViewedProducts.map(async (v) => {
        const product = await db.select().from(products).where(eq(products.id, v.productId)).limit(1)
        if (product.length === 0) return null
        return {
          name: product[0].name,
          category: product[0].category,
          views: v.totalViews,
        }
      })
    )

    // =============================================
    // 6. DAILY STATS FOR CHARTS
    // =============================================
    const dailyStats = []
    const interval = (timeFrame === '3m' || timeFrame === '6m') ? 7 : (timeFrame === '1y' ? 14 : 1)
    
    for (let i = days - 1; i >= 0; i -= interval) {
      const date = new Date(now)
      date.setDate(date.getDate() - i)
      const dayStart = new Date(date.setHours(0, 0, 0, 0))
      const dayEnd = new Date(date)
      dayEnd.setHours(23, 59, 59, 999)

      const dayOrders = approvedOrders.filter(o => {
        if (!o.createdAt) return false
        const orderDate = new Date(o.createdAt)
        return orderDate >= dayStart && orderDate <= dayEnd
      })

      // Get views for this day
      const dateStr = dayStart.toISOString().split('T')[0]
      const dayViews = filteredViews.filter(v => v.date === dateStr)
      const totalDayViews = dayViews.reduce((sum, v) => sum + (v.viewCount || 0), 0)

      dailyStats.push({
        date: dateStr,
        sales: dayOrders.reduce((sum, o) => {
          // Count items in order
          return sum + 1 // Simplified - in production you'd count items
        }, 0),
        revenue: dayOrders.reduce((sum, o) => sum + Math.round(parseFloat(String(o.total)) || 0), 0),
        orders: dayOrders.length,
        visitors: totalDayViews || 0,
      })
    }

    // =============================================
    // 7. CART EVENTS
    // =============================================
    const cartAdditions = await db.select().from(cartEvents)
      .where(eq(cartEvents.action, 'add'))
    
    const filteredCartAdditions = cartAdditions.filter(c => {
      if (!c.date) return false
      return new Date(c.date) >= startDate
    })

    const totalCartAdds = filteredCartAdditions.length

    // =============================================
    // 8. CALCULATED METRICS
    // =============================================
    const avgOrderValue = totalOrdersCount > 0 ? totalRevenue / totalOrdersCount : 0
    const conversionRate = totalViews > 0 ? (totalOrdersCount / totalViews) * 100 : 0
    const revPerVisitor = totalViews > 0 ? totalRevenue / totalViews : 0

    // =============================================
    // 9. DEVICE/BROWSER STATS (from actual sessions or defaults)
    // =============================================
    // Note: Device tracking requires visitor_sessions table
    // For now, we return zeros to indicate no data rather than fake percentages
    let deviceStats = {
      mobile: 0,
      desktop: 0,
      tablet: 0,
      ios: 0,
      android: 0,
      chrome: 0,
      safari: 0,
      other: 0,
      total: 0
    }

    // Try to get device stats if visitor_sessions table exists
    try {
      const sessionsResult = await db.execute(sql`
        SELECT device_type, browser, os, COUNT(*) as count 
        FROM visitor_sessions 
        WHERE date >= ${startDate.toISOString().split('T')[0]}
        GROUP BY device_type, browser, os
      `)
      
      if (sessionsResult.rows && sessionsResult.rows.length > 0) {
        deviceStats.total = sessionsResult.rows.reduce((sum: number, r: any) => sum + parseInt(r.count), 0)
        
        sessionsResult.rows.forEach((r: any) => {
          const count = parseInt(r.count)
          if (r.device_type === 'mobile') deviceStats.mobile += count
          else if (r.device_type === 'desktop') deviceStats.desktop += count
          else if (r.device_type === 'tablet') deviceStats.tablet += count
          
          if (r.os === 'ios' || r.os === 'iPhone') deviceStats.ios += count
          else if (r.os === 'android') deviceStats.android += count
          
          if (r.browser === 'chrome') deviceStats.chrome += count
          else if (r.browser === 'safari') deviceStats.safari += count
          else deviceStats.other += count
        })
      }
    } catch (e) {
      // Table doesn't exist yet - return zeros
      console.log('visitor_sessions table not found, returning empty device stats')
    }

    // =============================================
    // RETURN COMPREHENSIVE DATA
    // =============================================
    return NextResponse.json({
      success: true,
      data: {
        // Core metrics
        totalRevenue,
        totalOrders: totalOrdersCount,
        pendingOrders: pendingOrdersCount,
        canceledOrders: canceledOrdersCount,
        totalCustomers,
        newCustomers,
        repeatCustomers: repeatCustomersCount,
        
        // Visitor metrics (REAL)
        totalViews,
        uniqueProductsViewed,
        totalCartAdds,
        
        // Calculated metrics
        avgOrderValue: Math.round(avgOrderValue),
        conversionRate: conversionRate.toFixed(2),
        revPerVisitor: revPerVisitor.toFixed(2),
        
        // Top lists
        topSellingProducts,
        mostViewedProducts: viewedProductsWithDetails.filter(Boolean),
        topCustomers,
        
        // Chart data
        dailyStats,
        
        // Device stats (real or zeros)
        deviceStats,
        
        // Time frame info
        timeFrame,
        days,
        startDate: startDate.toISOString(),
      }
    })
  } catch (error) {
    console.error('Dashboard analytics error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch dashboard analytics',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}
