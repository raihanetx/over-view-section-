import { NextResponse } from 'next/server'
import { db } from '@/db'
import { categories, products, settings, variants } from '@/db/schema'
import { eq, sql } from 'drizzle-orm'

// In-memory cache for lightning-fast responses
let cachedData: {
  categories: any[]
  products: any[]
  settings: any
  timestamp: number
} | null = null

const CACHE_TTL = 30 * 1000 // 30 seconds cache for fresh data

// GET /api/shop-data - Get ALL shop data in ONE request (cached)
export async function GET() {
  const now = Date.now()
  
  // Return cached data if still valid (lightning fast!)
  if (cachedData && (now - cachedData.timestamp) < CACHE_TTL) {
    return NextResponse.json({
      success: true,
      cached: true,
      data: cachedData
    })
  }

  try {
    // Execute all queries in PARALLEL - much faster!
    const [categoriesData, productsData, settingsData, variantsData] = await Promise.all([
      db.select().from(categories),
      db.select().from(products),
      db.select().from(settings).limit(1),
      db.select().from(variants)
    ])

    // Process settings
    let settingsObj = {
      websiteName: 'EcoMart',
      slogan: '',
      logoUrl: '',
      faviconUrl: '',
      heroImages: [] as string[],
      whatsappNumber: '',
      phoneNumber: '',
      facebookUrl: '',
      messengerUsername: '',
      insideDhakaDelivery: 60,
      outsideDhakaDelivery: 120,
      freeDeliveryMin: 500,
      universalDelivery: false,
      universalDeliveryCharge: 60,
    }

    if (settingsData.length > 0) {
      const s = settingsData[0]
      let heroImagesArr: string[] = []
      
      if (s.heroImages) {
        try {
          const parsed = typeof s.heroImages === 'string' ? JSON.parse(s.heroImages) : s.heroImages
          heroImagesArr = Array.isArray(parsed) ? parsed : []
        } catch {
          heroImagesArr = []
        }
      }

      settingsObj = {
        websiteName: s.websiteName || 'EcoMart',
        slogan: s.slogan || '',
        logoUrl: s.logoUrl || '',
        faviconUrl: s.faviconUrl || '',
        heroImages: heroImagesArr,
        whatsappNumber: s.whatsappNumber || '',
        phoneNumber: s.phoneNumber || '',
        facebookUrl: s.facebookUrl || '',
        messengerUsername: s.messengerUsername || '',
        insideDhakaDelivery: Number(s.insideDhakaDelivery) || 60,
        outsideDhakaDelivery: Number(s.outsideDhakaDelivery) || 120,
        freeDeliveryMin: Number(s.freeDeliveryMin) || 500,
        universalDelivery: s.universalDelivery || false,
        universalDeliveryCharge: Number(s.universalDeliveryCharge) || 60,
      }
    }

    // Build variant map for quick lookup (include discount info)
    const variantMap: Record<number, any[]> = {}
    for (const v of variantsData) {
      if (!variantMap[v.productId]) {
        variantMap[v.productId] = []
      }
      variantMap[v.productId].push({
        id: v.id,
        name: v.name,
        stock: v.stock,
        price: Number(v.price) || 0,
        discount: v.discount || '0%',
        discountType: v.discountType || 'pct',
        discountValue: Number(v.discountValue) || 0,
      })
    }

    // Process products - add stock status
    const processedProducts = productsData.map(p => {
      const productVariants = variantMap[p.id] || []
      const minStock = productVariants.length > 0 
        ? Math.min(...productVariants.map(v => v.stock))
        : 0
      
      // Parse discount values
      const discountValue = p.discountValue ? parseFloat(p.discountValue.toString()) : 0
      
      return {
        id: p.id,
        name: p.name,
        category: p.category,
        categoryId: p.categoryId,
        image: p.image,
        price: Number(p.price) || 0,
        oldPrice: p.oldPrice ? Number(p.oldPrice) : null,
        discount: p.discount,
        discountType: p.discountType || 'pct',
        discountValue: discountValue,
        offer: p.offer === true || p.offer === 1,
        status: p.status,
        shortDesc: p.shortDesc,
        inStock: minStock > 0,
        stockCount: minStock,
        hasVariants: productVariants.length > 0,
      }
    })

    // Build response
    const data = {
      categories: categoriesData,
      products: processedProducts,
      settings: settingsObj,
      variantMap,
    }

    // Update cache
    cachedData = data

    return NextResponse.json({
      success: true,
      cached: false,
      data
    })
  } catch (error) {
    console.error('Shop data fetch error:', error)
    
    // Return cached data if available, even if expired
    if (cachedData) {
      return NextResponse.json({
        success: true,
        cached: true,
        stale: true,
        data: cachedData
      })
    }
    
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch shop data'
    }, { status: 500 })
  }
}

// Clear cache when data is updated (called from other APIs)
export function clearShopDataCache() {
  cachedData = null
}
