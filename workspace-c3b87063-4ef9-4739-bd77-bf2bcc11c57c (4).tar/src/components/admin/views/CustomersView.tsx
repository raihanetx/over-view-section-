'use client'

import React, { useState, useMemo } from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'
import type { AbandonedProduct } from '@/types'
import { roundPrice } from '@/lib/utils'

type CustomerFilter = 'all' | 'new' | 'regular' | 'vip'

const CustomersView: React.FC = () => {
  const { customerProfiles, expandedCustomer, setExpandedCustomer, showToastMsg } = useAdmin()
  const [filter, setFilter] = useState<CustomerFilter>('all')
  const [searchQuery, setSearchQuery] = useState('')

  const getInitials = (name: string) => {
    if (!name || name === 'Unknown') return '?'
    return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  }

  const buildEntries = (products: AbandonedProduct[]) => {
    if (!products || !Array.isArray(products)) return []
    const entries: { name: string; variant: string | null; qty: number }[] = []
    products.forEach(p => {
      if (p && p.variants && Array.isArray(p.variants)) {
        p.variants.forEach(v => entries.push({ name: p.name, variant: v.label, qty: v.qty }))
      }
    })
    return entries
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    showToastMsg('Number copied!')
  }

  const toggleExpand = (id: number) => {
    setExpandedCustomer(expandedCustomer === id ? null : id)
  }

  // Filter counts
  const filterCounts = useMemo(() => ({
    all: customerProfiles.length,
    new: customerProfiles.filter(c => (c.totalOrders || 0) === 1).length,
    regular: customerProfiles.filter(c => (c.totalOrders || 0) >= 2 && (c.totalOrders || 0) <= 5).length,
    vip: customerProfiles.filter(c => (c.totalSpent || 0) >= 1000 || (c.totalOrders || 0) > 5).length,
  }), [customerProfiles])

  // Filter customers
  const filteredByStatus = useMemo(() => {
    if (filter === 'all') return customerProfiles
    if (filter === 'new') return customerProfiles.filter(c => (c.totalOrders || 0) === 1)
    if (filter === 'regular') return customerProfiles.filter(c => (c.totalOrders || 0) >= 2 && (c.totalOrders || 0) <= 5)
    if (filter === 'vip') return customerProfiles.filter(c => (c.totalSpent || 0) >= 1000 || (c.totalOrders || 0) > 5)
    return customerProfiles
  }, [customerProfiles, filter])

  // Search filter
  const filteredCustomers = filteredByStatus.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.phone.includes(searchQuery)
  )

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Filter Tabs */}
      <div className="flex gap-2 mb-4 flex-wrap items-center">
        <button onClick={() => setFilter('all')} className={`px-4 py-2 text-sm font-medium transition-all border ${filter === 'all' ? 'border-[#1e293b] text-[#1e293b] bg-[#1e293b]/5' : 'border-gray-300 text-gray-600 hover:border-gray-400'}`} style={{ borderRadius: '5px' }}>All ({filterCounts.all})</button>
        <button onClick={() => setFilter('new')} className={`px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border ${filter === 'new' ? 'border-amber-500 text-amber-600 bg-amber-50' : 'border-gray-300 text-gray-600 hover:border-gray-400'}`} style={{ borderRadius: '5px' }}><i className="ri-user-add-line text-sm"></i>New ({filterCounts.new})</button>
        <button onClick={() => setFilter('regular')} className={`px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border ${filter === 'regular' ? 'border-[#16a34a] text-[#16a34a] bg-green-50' : 'border-gray-300 text-gray-600 hover:border-gray-400'}`} style={{ borderRadius: '5px' }}><i className="ri-user-heart-line text-sm"></i>Regular ({filterCounts.regular})</button>
        <button onClick={() => setFilter('vip')} className={`px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border ${filter === 'vip' ? 'border-purple-500 text-purple-600 bg-purple-50' : 'border-gray-300 text-gray-600 hover:border-gray-400'}`} style={{ borderRadius: '5px' }}><i className="ri-vip-crown-line text-sm"></i>VIP ({filterCounts.vip})</button>
        <div className="flex items-center gap-2 ml-auto border border-gray-300 px-3 py-1.5 focus-within:border-[#16a34a]" style={{ borderRadius: '5px' }}>
          <i className="ri-search-line text-gray-400 text-sm"></i>
          <input type="text" placeholder="Search..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="bg-transparent border-none outline-none text-[13px] w-32 md:w-40" />
        </div>
      </div>

      {/* Table */}
      <div className="flex flex-col gap-2">
        {/* Header */}
        <div className="grid grid-cols-5 bg-[#f1f5f9] border border-[#e2e8f0]" style={{ borderRadius: '5px' }}>
          <div className="px-4 py-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Name / Phone</div>
          <div className="px-4 py-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Address</div>
          <div className="px-4 py-3 border-r border-[#e2e8f0] text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Orders / Spent</div>
          <div className="px-4 py-3 border-r border-[#e2e8f0] text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Last Order</div>
          <div className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Actions</div>
        </div>

        {/* Rows */}
        {filteredCustomers.length === 0 ? (
          <div className="bg-white border border-[#e2e8f0] p-12 text-center" style={{ borderRadius: '5px' }}>
            <p className="text-[#94a3b8] text-sm">No customers found.</p>
          </div>
        ) : (
          filteredCustomers.map((cust) => (
            <div key={cust.id} className="flex flex-col">
              {/* Main Row */}
              <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
                {/* Name / Phone */}
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs bg-purple-100 text-purple-600 border-2 border-purple-200 flex-shrink-0">{getInitials(cust.name)}</div>
                  <div className="min-w-0">
                    <p className="text-[13px] font-semibold text-[#1e293b] truncate">{cust.name}</p>
                    <p className="text-[11px] text-[#94a3b8]">{cust.phone}</p>
                  </div>
                </div>
                
                {/* Address */}
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center">
                  <p className="text-[12px] text-[#64748b] truncate">{cust.address || 'No address'}</p>
                </div>
                
                {/* Orders / Spent */}
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-[13px] font-semibold text-[#1e293b]">{cust.totalOrders || 0} orders</p>
                    <p className="text-[11px] text-[#16a34a]">TK {roundPrice(cust.totalSpent || 0)}</p>
                  </div>
                </div>
                
                {/* Last Order */}
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center justify-center">
                  <span className="text-[12px] text-[#6b7280]">{cust.lastOrderAgo || cust.lastVisit || '-'}</span>
                </div>
                
                {/* Actions */}
                <div className="px-4 py-3 flex items-center justify-center gap-1">
                  <button className="act-btn w-7 h-7 flex items-center justify-center text-gray-500 bg-gray-100 hover:bg-green-100 hover:text-green-600 transition-all" style={{ borderRadius: '5px' }} onClick={() => window.location.href = `tel:${cust.phone}`}><i className="ri-phone-line text-sm"></i></button>
                  <button className="act-btn w-7 h-7 flex items-center justify-center text-gray-500 bg-gray-100 hover:bg-green-100 hover:text-green-600 transition-all" style={{ borderRadius: '5px' }} onClick={() => window.open(`https://wa.me/${cust.phone.replace('+', '')}`, '_blank')}><i className="ri-whatsapp-line text-sm"></i></button>
                  <button className="act-btn w-7 h-7 flex items-center justify-center text-gray-500 bg-gray-100 hover:bg-gray-200 transition-all" style={{ borderRadius: '5px' }} onClick={() => copyToClipboard(cust.phone)}><i className="ri-file-copy-line text-sm"></i></button>
                  <button className="act-btn w-7 h-7 flex items-center justify-center text-gray-500 bg-gray-100 hover:bg-gray-200 transition-all" style={{ borderRadius: '5px' }} onClick={() => toggleExpand(cust.id)}>
                    <i className="ri-arrow-down-s-line text-gray-400 transition-transform duration-200" style={{ transform: expandedCustomer === cust.id ? 'rotate(180deg)' : 'rotate(0deg)' }}></i>
                  </button>
                </div>
              </div>

              {/* Expand - Order History */}
              <div className="overflow-hidden transition-all duration-300 bg-[#f8fafc]" style={{ maxHeight: expandedCustomer === cust.id ? '2000px' : '0', borderRadius: expandedCustomer === cust.id ? '5px' : '0', marginTop: expandedCustomer === cust.id ? '4px' : '0', border: expandedCustomer === cust.id ? '1px solid #e2e8f0' : 'none' }}>
                <div className="p-4">
                  {/* Header */}
                  <div className="grid grid-cols-12 bg-[#f1f5f9] border border-[#e2e8f0] mb-2" style={{ borderRadius: '5px' }}>
                    <div className="col-span-2 px-3 py-2 text-[10px] font-semibold uppercase text-[#64748b]">Visit #</div>
                    <div className="col-span-3 px-3 py-2 text-[10px] font-semibold uppercase text-[#64748b]">Date</div>
                    <div className="col-span-5 px-3 py-2 text-[10px] font-semibold uppercase text-[#64748b]">Products</div>
                    <div className="col-span-2 px-3 py-2 text-[10px] font-semibold uppercase text-[#64748b] text-right">Total</div>
                  </div>
                  
                  {(cust.orders || []).map((o, idx) => {
                    const entries = buildEntries(o.products || [])
                    return (
                      <div key={idx} className="grid grid-cols-12 py-2 border-b border-[#e2e8f0] last:border-0 items-center">
                        <div className="col-span-2 px-3 text-[12px] font-medium text-[#1e293b]">Visit #{idx + 1}</div>
                        <div className="col-span-3 px-3 text-[12px] text-[#64748b]">{o.date} {o.time && <span className="text-[#94a3b8]">• {o.time}</span>}</div>
                        <div className="col-span-5 px-3">
                          <div className="flex items-center gap-2 text-[11px] text-[#64748b]">
                            <span className="truncate">
                              {entries.map((e, i) => (
                                <span key={i}>
                                  <span className="font-medium text-[#1e293b]">{e.name}</span>
                                  {e.variant && <span className="text-[#94a3b8]"> • {e.variant}</span>}
                                  <span className="text-green-600"> • {e.qty} items</span>
                                  {i < entries.length - 1 && <span className="text-[#cbd5e1]"> ------ </span>}
                                </span>
                              ))}
                            </span>
                          </div>
                        </div>
                        <div className="col-span-2 px-3 text-right text-[13px] font-bold text-green-600">TK {roundPrice(o.total || 0)}</div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

export default CustomersView
