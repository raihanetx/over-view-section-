'use client'

import React, { useState, useMemo } from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'

type StockFilter = 'all' | 'low' | 'medium' | 'settings'

const InventoryView: React.FC = () => {
  const { 
    inventory, 
    setInventory, 
    editingInventoryItem, 
    setEditingInventoryItem,
    showToastMsg,
    refetchInventory,
    settings,
    setSettings
  } = useAdmin()

  const [deletingId, setDeletingId] = useState<number | null>(null)
  const [stockFilter, setStockFilter] = useState<StockFilter>('all')
  const [savingSettings, setSavingSettings] = useState(false)

  // Get percentage thresholds from settings (default: low=25%, medium=50%)
  const lowPercent = settings.stockLowPercent ?? 25
  const mediumPercent = settings.stockMediumPercent ?? 50

  // Update threshold values
  const [tempLowPercent, setTempLowPercent] = useState(lowPercent)
  const [tempMediumPercent, setTempMediumPercent] = useState(mediumPercent)

  // Get stock level percentage for a product
  const getStockLevel = (variants: { stock: number; initialStock: number }[]): 'low' | 'medium' | 'high' => {
    const totalStock = variants.reduce((acc, v) => acc + v.stock, 0)
    const totalInitial = variants.reduce((acc, v) => acc + (v.initialStock || v.stock), 0)
    
    if (totalInitial === 0) return 'high'
    
    const percentRemaining = (totalStock / totalInitial) * 100
    
    if (percentRemaining <= lowPercent) return 'low'
    if (percentRemaining <= mediumPercent) return 'medium'
    return 'high'
  }

  // Get percentage for display
  const getStockPercent = (variants: { stock: number; initialStock: number }[]): number => {
    const totalStock = variants.reduce((acc, v) => acc + v.stock, 0)
    const totalInitial = variants.reduce((acc, v) => acc + (v.initialStock || v.stock), 0)
    if (totalInitial === 0) return 100
    return Math.round((totalStock / totalInitial) * 100)
  }

  // Filter inventory based on stock level
  const filteredInventory = useMemo(() => {
    if (stockFilter === 'all') return inventory
    if (stockFilter === 'settings') return []
    return inventory.filter(item => getStockLevel(item.variants) === stockFilter)
  }, [inventory, stockFilter, lowPercent, mediumPercent])

  // Count by stock level
  const stockCounts = useMemo(() => ({
    all: inventory.length,
    low: inventory.filter(i => getStockLevel(i.variants) === 'low').length,
    medium: inventory.filter(i => getStockLevel(i.variants) === 'medium').length,
  }), [inventory, lowPercent, mediumPercent])

  const handleDeleteInventory = async (item: { id: number; name: string }) => {
    if (!confirm(`Are you sure you want to delete "${item.name}"? This will also delete all its variants.`)) {
      return
    }
    
    setDeletingId(item.id)
    try {
      const response = await fetch(`/api/products?id=${item.id}`, {
        method: 'DELETE'
      })
      const data = await response.json()
      
      if (data.success) {
        setInventory(inventory.filter(i => i.id !== item.id))
        showToastMsg('Product deleted successfully!')
      } else {
        showToastMsg('Failed to delete product')
      }
    } catch (error) {
      console.error('Error deleting inventory:', error)
      showToastMsg('Failed to delete product')
    } finally {
      setDeletingId(null)
    }
  }

  const saveInventorySettings = async () => {
    setSavingSettings(true)
    try {
      const response = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...settings,
          stockLowPercent: tempLowPercent,
          stockMediumPercent: tempMediumPercent,
        }),
      })
      
      const result = await response.json()
      
      if (result.success) {
        setSettings({ 
          ...settings, 
          stockLowPercent: tempLowPercent, 
          stockMediumPercent: tempMediumPercent 
        })
        showToastMsg('Settings saved!')
      } else {
        showToastMsg('Failed to save settings')
      }
    } catch (error) {
      console.error('Error saving settings:', error)
      showToastMsg('Failed to save settings')
    } finally {
      setSavingSettings(false)
    }
  }

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Filter Tabs */}
      <div className="flex gap-2 mb-4 flex-wrap">
        <button
          onClick={() => setStockFilter('all')}
          className={`px-4 py-2 text-sm font-medium transition-all border ${
            stockFilter === 'all' 
              ? 'border-[#1e293b] text-[#1e293b] bg-[#1e293b]/5' 
              : 'border-gray-300 text-gray-600 hover:border-gray-400'
          }`}
          style={{ borderRadius: '5px' }}
        >
          All ({stockCounts.all})
        </button>
        <button
          onClick={() => setStockFilter('low')}
          className={`px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border ${
            stockFilter === 'low' 
              ? 'border-red-500 text-red-600 bg-red-50' 
              : 'border-red-300 text-red-500 hover:border-red-400'
          }`}
          style={{ borderRadius: '5px' }}
        >
          <span className="w-2 h-2 rounded-full bg-red-500"></span>
          Low ({stockCounts.low})
        </button>
        <button
          onClick={() => setStockFilter('medium')}
          className={`px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border ${
            stockFilter === 'medium' 
              ? 'border-amber-500 text-amber-600 bg-amber-50' 
              : 'border-amber-300 text-amber-500 hover:border-amber-400'
          }`}
          style={{ borderRadius: '5px' }}
        >
          <span className="w-2 h-2 rounded-full bg-amber-500"></span>
          Medium ({stockCounts.medium})
        </button>
        <button
          onClick={() => setStockFilter('settings')}
          className={`px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border ${
            stockFilter === 'settings' 
              ? 'border-[#16a34a] text-[#16a34a] bg-green-50' 
              : 'border-gray-300 text-gray-600 hover:border-gray-400'
          }`}
          style={{ borderRadius: '5px' }}
        >
          <i className="ri-settings-3-line text-sm"></i>
          Settings
        </button>
      </div>

      {/* Settings Panel */}
      {stockFilter === 'settings' && (
        <div className="bg-white border border-[#e2e8f0] rounded-lg p-6 mb-4">
          <h3 className="text-sm font-semibold text-[#1e293b] mb-4">Stock Level Thresholds (Percentage)</h3>
          <p className="text-xs text-[#64748b] mb-6">Set when stock levels are considered low or medium based on remaining percentage</p>
          
          <div className="grid grid-cols-2 gap-6 max-w-md">
            <div>
              <label className="block text-xs font-medium text-[#475569] mb-2 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-500"></span>
                Low Stock (Below or Equal)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={tempLowPercent}
                  onChange={(e) => setTempLowPercent(parseInt(e.target.value) || 0)}
                  className="w-20 px-3 py-2 bg-white border border-[#e2e8f0] rounded-lg text-sm outline-none focus:border-[#16a34a]"
                  min="0"
                  max="100"
                />
                <span className="text-sm text-[#64748b]">%</span>
              </div>
              <p className="text-xs text-[#94a3b8] mt-2">Remaining stock at or below this is low</p>
            </div>
            <div>
              <label className="block text-xs font-medium text-[#475569] mb-2 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                Medium Stock (Below or Equal)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={tempMediumPercent}
                  onChange={(e) => setTempMediumPercent(parseInt(e.target.value) || 0)}
                  className="w-20 px-3 py-2 bg-white border border-[#e2e8f0] rounded-lg text-sm outline-none focus:border-[#16a34a]"
                  min="0"
                  max="100"
                />
                <span className="text-sm text-[#64748b]">%</span>
              </div>
              <p className="text-xs text-[#94a3b8] mt-2">Remaining stock at or below this is medium</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 bg-[#f8fafc] rounded-lg border border-[#e2e8f0] mt-6 max-w-lg">
            <i className="ri-information-line text-[#64748b] text-lg"></i>
            <div className="text-xs text-[#64748b]">
              <p className="font-medium text-[#0f172a] mb-1">Example (Low: {tempLowPercent}%, Medium: {tempMediumPercent}%):</p>
              <ul className="mt-1 space-y-0.5">
                <li>• Added 100, remaining 10 = 10% = <span className="text-red-500 font-medium">Low</span></li>
                <li>• Added 100, remaining 40 = 40% = <span className="text-amber-500 font-medium">Medium</span></li>
                <li>• Added 100, remaining 80 = 80% = <span className="text-green-500 font-medium">High</span></li>
              </ul>
            </div>
          </div>

          <button
            onClick={saveInventorySettings}
            disabled={savingSettings}
            className="mt-6 px-4 py-2 bg-[#16a34a] text-white text-sm font-medium rounded-lg hover:bg-[#15803d] transition-colors disabled:bg-[#cbd5e1]"
          >
            {savingSettings ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      )}

      {/* Inventory Table */}
      {stockFilter !== 'settings' && (
        <div className="flex flex-col gap-2">
          {/* Header Row */}
          <div className="grid grid-cols-4 bg-[#f1f5f9] border border-[#e2e8f0] rounded-[5px]">
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Product</div>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center justify-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Varieties</div>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center justify-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Last Edited</div>
            <div className="px-4 py-3 flex items-center justify-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Action</div>
          </div>

          {/* Data Rows */}
          {filteredInventory.map((item) => {
            const stockLevel = getStockLevel(item.variants)
            const stockPercent = getStockPercent(item.variants)
            
            return (
              <div 
                key={item.id}
                className="grid grid-cols-4 bg-white rounded-[5px] border border-[#e2e8f0] overflow-hidden hover:border-[#94a3b8] hover:shadow-sm transition-all"
              >
                {/* Product */}
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-3">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-10 h-10 rounded-[5px] object-cover flex-shrink-0 border border-[#d1d5db]" 
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-[#1e293b] truncate">{item.name}</p>
                    <p className="text-[11px] text-[#94a3b8] truncate">{item.category}</p>
                  </div>
                </div>
                
                {/* Varieties - just names */}
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center justify-center">
                  <div className="flex items-center justify-center gap-1">
                    {item.variants.length > 0 ? (
                      item.variants.map((v, idx) => (
                        <React.Fragment key={idx}>
                          <span className="text-[12px] font-medium text-[#1e293b]">{v.name}</span>
                          {idx < item.variants.length - 1 && (
                            <span className="text-[#cbd5e1] mx-1">|</span>
                          )}
                        </React.Fragment>
                      ))
                    ) : (
                      <span className="text-[12px] text-[#94a3b8]">No variants</span>
                    )}
                  </div>
                </div>
                
                {/* Last Edited with stock percentage indicator */}
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center justify-center gap-2">
                  {stockLevel === 'low' && (
                    <span className="text-[10px] font-semibold text-red-500 bg-red-50 px-2 py-0.5 rounded">{stockPercent}% Low</span>
                  )}
                  {stockLevel === 'medium' && (
                    <span className="text-[10px] font-semibold text-amber-500 bg-amber-50 px-2 py-0.5 rounded">{stockPercent}% Medium</span>
                  )}
                  <span className="text-[12px] text-[#6b7280]">{item.lastEdited}</span>
                </div>
                
                {/* Action */}
                <div className="px-4 py-3 flex items-center justify-center gap-1">
                  <button 
                    onClick={() => setEditingInventoryItem(item)} 
                    className="px-3 py-1.5 text-[11px] font-medium text-[#475569] bg-[#f1f5f9] rounded-md hover:bg-[#e2e8f0] hover:text-[#1e293b] transition-colors"
                  >
                    Edit
                  </button>
                  <button 
                    onClick={() => handleDeleteInventory(item)} 
                    disabled={deletingId === item.id}
                    className="px-3 py-1.5 text-[11px] font-medium text-[#ef4444] bg-[#fef2f2] rounded-md hover:bg-[#fee2e2] transition-colors disabled:opacity-50"
                  >
                    {deletingId === item.id ? '...' : 'Delete'}
                  </button>
                </div>
              </div>
            )
          })}
          
          {filteredInventory.length === 0 && (
            <div className="bg-white rounded-[5px] border border-[#e2e8f0] p-12 text-center">
              <p className="text-[#94a3b8] text-sm">No products found for this filter.</p>
            </div>
          )}
        </div>
      )}
      
      {/* Inventory Edit Modal */}
      {editingInventoryItem && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setEditingInventoryItem(null)}></div>
          <div className="relative bg-white w-full max-w-lg rounded-xl shadow-2xl p-6 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-[#1c2333]">Edit Stock - {editingInventoryItem.name}</h3>
              <button onClick={() => setEditingInventoryItem(null)} className="text-[#8a96a8] hover:text-[#1c2333]">
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            
            <div className="space-y-3">
              {editingInventoryItem.variants.map((variant, idx) => {
                const sold = (variant.initialStock || variant.stock) - variant.stock
                return (
                  <div key={idx} className="p-4 bg-white rounded-lg border border-[#e4e7ee]">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-semibold text-[#1c233b]">{variant.name}</div>
                      <div className="text-[12px] text-[#16a34a] font-medium">
                        {sold} sold
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-[12px] text-[#64748b]">
                        Current: <span className="font-semibold text-[#1e293b]">{variant.stock}</span> out of <span className="font-semibold">{variant.initialStock || variant.stock}</span>
                      </div>
                      <input 
                        type="number"
                        value={variant.stock}
                        onChange={(e) => {
                          const newVariants = [...editingInventoryItem.variants];
                          newVariants[idx].stock = parseInt(e.target.value) || 0;
                          setEditingInventoryItem({...editingInventoryItem, variants: newVariants});
                        }}
                        className="w-20 px-3 py-2 border border-[#e4e7ee] rounded-lg text-center focus:outline-none focus:border-[#16a34a] text-sm"
                        placeholder="Stock"
                      />
                    </div>
                  </div>
                )
              })}
            </div>
            
            <div className="flex gap-3 mt-6">
              <button 
                onClick={() => setEditingInventoryItem(null)}
                className="flex-1 px-4 py-2 border border-[#e4e7ee] text-[#8a96a8] rounded-lg font-semibold hover:bg-[#f5f6f9] transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={async () => {
                  try {
                    for (const variant of editingInventoryItem.variants) {
                      if (variant.id) {
                        await fetch('/api/inventory', {
                          method: 'PUT',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({
                            variantId: variant.id,
                            stock: variant.stock
                          })
                        })
                      }
                    }
                    refetchInventory()
                    setEditingInventoryItem(null)
                    showToastMsg('Stock updated successfully!')
                  } catch (error) {
                    console.error('Error saving inventory:', error)
                    showToastMsg('Failed to update stock')
                  }
                }}
                className="flex-1 px-4 py-2 bg-[#16a34a] text-white rounded-lg font-semibold hover:bg-[#15803d] transition-colors"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default InventoryView
