'use client'

import React, { useState, useMemo } from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'
import type { AbandonedProduct } from '@/types'
import { roundPrice } from '@/lib/utils'

type AbandonedFilter = 'all' | 'new' | 'returning' | 'high-value'

const AbandonedView: React.FC = () => {
  const { abandonedCheckouts } = useAdmin()
  const [expandedId, setExpandedId] = useState<number | null>(null)
  const [filter, setFilter] = useState<AbandonedFilter>('all')

  const getInitials = (name: string) => {
    if (!name || name === 'Unknown') return '?'
    return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  }

  const buildEntries = (products: AbandonedProduct[]) => {
    if (!products || !Array.isArray(products)) return []
    const entries: { name: string; variant: string | null; qty: number }[] = []
    products.forEach(p => {
      if (p && p.variants && Array.isArray(p.variants)) {
        p.variants.forEach(v => entries.push({ name: p.name, variant: v.label, qty: v.qty }))
      }
    })
    return entries
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const toggleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id)
  }

  // Filter counts
  const filterCounts = useMemo(() => ({
    all: abandonedCheckouts.length,
    new: abandonedCheckouts.filter(ab => ab.totalVisits === 1).length,
    returning: abandonedCheckouts.filter(ab => ab.totalVisits > 1).length,
    highValue: abandonedCheckouts.filter(ab => Math.max(...(ab.history || []).map(h => h.total || 0)) >= 500).length,
  }), [abandonedCheckouts])

  // Filter
  const filteredCheckouts = useMemo(() => {
    if (filter === 'all') return abandonedCheckouts
    if (filter === 'new') return abandonedCheckouts.filter(ab => ab.totalVisits === 1)
    if (filter === 'returning') return abandonedCheckouts.filter(ab => ab.totalVisits > 1)
    if (filter === 'high-value') return abandonedCheckouts.filter(ab => Math.max(...(ab.history || []).map(h => h.total || 0)) >= 500)
    return abandonedCheckouts
  }, [abandonedCheckouts, filter])

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Filter Tabs */}
      <div className="flex gap-2 mb-4 flex-wrap">
        <button onClick={() => setFilter('all')} className={`px-4 py-2 text-sm font-medium transition-all border ${filter === 'all' ? 'border-[#1e293b] text-[#1e293b] bg-[#1e293b]/5' : 'border-gray-300 text-gray-600 hover:border-gray-400'}`} style={{ borderRadius: '5px' }}>All ({filterCounts.all})</button>
        <button onClick={() => setFilter('new')} className={`px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border ${filter === 'new' ? 'border-amber-500 text-amber-600 bg-amber-50' : 'border-gray-300 text-gray-600 hover:border-gray-400'}`} style={{ borderRadius: '5px' }}><i className="ri-user-add-line text-sm"></i>New ({filterCounts.new})</button>
        <button onClick={() => setFilter('returning')} className={`px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border ${filter === 'returning' ? 'border-[#16a34a] text-[#16a34a] bg-green-50' : 'border-gray-300 text-gray-600 hover:border-gray-400'}`} style={{ borderRadius: '5px' }}><i className="ri-user-follow-line text-sm"></i>Returning ({filterCounts.returning})</button>
        <button onClick={() => setFilter('high-value')} className={`px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border ${filter === 'high-value' ? 'border-purple-500 text-purple-600 bg-purple-50' : 'border-gray-300 text-gray-600 hover:border-gray-400'}`} style={{ borderRadius: '5px' }}><i className="ri-vip-crown-line text-sm"></i>High Value ({filterCounts.highValue})</button>
      </div>

      {/* Table */}
      <div className="flex flex-col gap-2">
        {/* Header */}
        <div className="grid grid-cols-5 bg-[#f1f5f9] border border-[#e2e8f0]" style={{ borderRadius: '5px' }}>
          <div className="px-4 py-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Name / Phone</div>
          <div className="px-4 py-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Address</div>
          <div className="px-4 py-3 border-r border-[#e2e8f0] text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Last Visit</div>
          <div className="px-4 py-3 border-r border-[#e2e8f0] text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Visits / Done</div>
          <div className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Actions</div>
        </div>

        {/* Rows */}
        {filteredCheckouts.length === 0 ? (
          <div className="bg-white border border-[#e2e8f0] p-12 text-center" style={{ borderRadius: '5px' }}>
            <i className="ri-shopping-cart-line text-4xl text-gray-300 block mb-3"></i>
            <p className="font-medium text-gray-500">No abandoned checkouts found.</p>
          </div>
        ) : (
          filteredCheckouts.map((ab) => (
            <div key={ab.id} className="flex flex-col">
              {/* Main Row */}
              <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
                {/* Name / Phone */}
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs bg-green-100 text-green-600 border-2 border-green-200 flex-shrink-0">{getInitials(ab.name)}</div>
                  <div className="min-w-0">
                    <p className="text-[13px] font-semibold text-[#1e293b] truncate">{ab.name || 'Unknown'}</p>
                    <p className="text-[11px] text-[#94a3b8]">{ab.phone || 'No phone'}</p>
                  </div>
                </div>
                
                {/* Address */}
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center">
                  <p className="text-[12px] text-[#64748b] truncate">{ab.address || 'No address'}</p>
                </div>
                
                {/* Last Visit */}
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-[12px] font-medium text-[#1e293b]">{ab.visitTime}</p>
                    <p className="text-[11px] text-[#94a3b8]">{ab.visitDate}</p>
                  </div>
                </div>
                
                {/* Visits / Done */}
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center justify-center">
                  <div className="flex items-center gap-2">
                    <span className="text-[13px] font-semibold text-[#1e293b]">{ab.totalVisits}</span>
                    <span className="text-[11px] text-[#94a3b8]">visits</span>
                    <span className="text-[#cbd5e1]">|</span>
                    <span className="text-[13px] font-semibold text-green-600">{ab.completedOrders}</span>
                    <span className="text-[11px] text-[#94a3b8]">done</span>
                  </div>
                </div>
                
                {/* Actions */}
                <div className="px-4 py-3 flex items-center justify-center gap-1">
                  <button className="act-btn w-7 h-7 flex items-center justify-center text-gray-500 bg-gray-100 hover:bg-green-100 hover:text-green-600 transition-all" style={{ borderRadius: '5px' }} onClick={() => window.location.href = `tel:${ab.phone}`}><i className="ri-phone-line text-sm"></i></button>
                  <button className="act-btn w-7 h-7 flex items-center justify-center text-gray-500 bg-gray-100 hover:bg-green-100 hover:text-green-600 transition-all" style={{ borderRadius: '5px' }} onClick={() => window.open(`https://wa.me/${(ab.phone || '').replace('+', '')}`, '_blank')}><i className="ri-whatsapp-line text-sm"></i></button>
                  <button className="act-btn w-7 h-7 flex items-center justify-center text-gray-500 bg-gray-100 hover:bg-gray-200 transition-all" style={{ borderRadius: '5px' }} onClick={() => { copyToClipboard(ab.phone || '') }}><i className="ri-file-copy-line text-sm"></i></button>
                  <button className="act-btn w-7 h-7 flex items-center justify-center text-gray-500 bg-gray-100 hover:bg-gray-200 transition-all" style={{ borderRadius: '5px' }} onClick={() => toggleExpand(ab.id)}>
                    <i className="ri-arrow-down-s-line text-gray-400 transition-transform duration-200" style={{ transform: expandedId === ab.id ? 'rotate(180deg)' : 'rotate(0deg)' }}></i>
                  </button>
                </div>
              </div>

              {/* Expand - History */}
              <div className="overflow-hidden transition-all duration-300 bg-[#f8fafc]" style={{ maxHeight: expandedId === ab.id ? '2000px' : '0', borderRadius: expandedId === ab.id ? '5px' : '0', marginTop: expandedId === ab.id ? '4px' : '0', border: expandedId === ab.id ? '1px solid #e2e8f0' : 'none' }}>
                <div className="p-4">
                  {/* Header */}
                  <div className="grid grid-cols-12 bg-[#f1f5f9] border border-[#e2e8f0] mb-2" style={{ borderRadius: '5px' }}>
                    <div className="col-span-2 px-3 py-2 text-[10px] font-semibold uppercase text-[#64748b]">Visit #</div>
                    <div className="col-span-3 px-3 py-2 text-[10px] font-semibold uppercase text-[#64748b]">Date</div>
                    <div className="col-span-5 px-3 py-2 text-[10px] font-semibold uppercase text-[#64748b]">Products</div>
                    <div className="col-span-2 px-3 py-2 text-[10px] font-semibold uppercase text-[#64748b] text-right">Total</div>
                  </div>
                  
                  {(ab.history || []).map((h, idx) => {
                    const entries = buildEntries(h.products || [])
                    const isCompleted = h.status === 'completed'
                    return (
                      <div key={idx} className="grid grid-cols-12 py-2 border-b border-[#e2e8f0] last:border-0 items-center">
                        <div className="col-span-2 px-3 text-[12px] font-medium text-[#1e293b]">Visit #{idx + 1}</div>
                        <div className="col-span-3 px-3 text-[12px] text-[#64748b]">{h.date} {h.time && <span className="text-[#94a3b8]">• {h.time}</span>}</div>
                        <div className="col-span-5 px-3">
                          <div className="flex items-center gap-2 text-[11px] text-[#64748b]">
                            <span className="truncate">
                              {entries.map((e, i) => (
                                <span key={i}>
                                  <span className="font-medium text-[#1e293b]">{e.name}</span>
                                  {e.variant && <span className="text-[#94a3b8]"> • {e.variant}</span>}
                                  <span className="text-green-600"> • {e.qty} items</span>
                                  {i < entries.length - 1 && <span className="text-[#cbd5e1]"> ------ </span>}
                                </span>
                              ))}
                            </span>
                          </div>
                        </div>
                        <div className="col-span-2 px-3 text-right">
                          <p className={`text-[13px] font-bold ${isCompleted ? 'text-green-600' : 'text-red-500'}`}>TK {roundPrice(h.total || 0)}</p>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

export default AbandonedView
